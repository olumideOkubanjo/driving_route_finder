/*
    Name1: Olumide Okubanjo (1573500)
    Name2: Mohamed Ali (1573724) 
    CMPUT 275 Wi20
    Major Assignment 2: Driving Route Finder Part - 1
*/

//Libraries Included
#include <iostream>
#include "wdigraph.h"
#include "dijkstra.h"
#include "utils.h"
#include <list>
#include <unordered_map>
using namespace std;

int main(){

    //Stores the verticies, edges and weights the graph.
    WDigraph edmontonMapData;

    //Stores the points on the graph as <id, Point>
    unordered_map<int, Point> allVertecies;

    //Load the data from the text file
    readGraph("edmonton-roads-2.0.1.txt", edmontonMapData, allVertecies);

    //Request Handling using stdin and stdout
    char command;
    while(true){
        cin >> command;

        if (command=='R'){
            long long startLat, startLong, endlat, endlong;

            cin >> startLat;
            cin >> startLong; 
            cin >> endlat;
            cin >> endlong;

            unordered_map<int, PIL> searchTree;
            list<int> path;

            Point startPoint;
            Point endPoint;

            startPoint.lat = startLat;
            startPoint.lon = startLong;

            endPoint.lat = endlat;
            endPoint.lon = endlong;

            int endID;
            int startID;
            long long startManDist = 100000000;
            long long endManDist = 100000000;

            //Finding the nearest vertex to the start and end points of verticies specified
            findStartAndEndVertexes(allVertecies, startPoint,endPoint,startManDist,endManDist,startID,endID);

            //Filling the searchtree with id nearst to the start vertex
            dijkstra(edmontonMapData,startID,searchTree);

            //Filling and printing the path
            if(searchTree.find(endID)==searchTree.end()){
                cout << "N 0" << endl;
            }else{
                int stepp = endID;
                while(stepp!=startID){
                    path.push_front(stepp);

                    stepp = searchTree[stepp].first;
                }

                path.push_front(startID);

                cout << "N " << path.size() << endl;

                while(!path.empty()){
                    char awk;
                    cin >> awk;
                    if(awk=='A'){
                        int printID = path.front();
                        printPoint(allVertecies[printID]); 
                        path.pop_front();
                    }
                }

                cout << "E" << endl;
                break;
            }
            
        }
    }

    return 0;
}