/*
    Utility Functions
*/

//Libraries included
#include <fstream>
#include "wdigraph.h"
#include <unordered_map>
#include <string>


/*
    Stucture to store the lon and lat
*/
struct Point {
    long long lat; // latitude of the point
    long long lon; // longitude of the point
};


/*
    Calculate the mahattan 
*/
long long manhattan(const Point& pt1, const Point& pt2) {
    //Calculating he manhattan distances based based on the longitde and latitute passed in.
    long long xDist = abs(pt2.lon - pt1.lon);
    long long yDist = abs(pt2.lat - pt1.lat);

    return xDist + yDist;
}

/*
    Prints the point structure that was passed through in the form:
        W lat lon 
*/
void printPoint(Point p){
    cout << "W "<< p.lat << " " << p.lon << endl;
}


/*
    Finding the nearst vertex to the start and end points passed in
    Updating the start and end ID's passed in
*/
void findStartAndEndVertexes(unordered_map<int, Point> vertList, Point startPoint, Point endPoint, 
                                        long long &startManDist, long long &endManDist, int &startID, 
                                        int &endID)
    {
    for(unordered_map<int, Point>::iterator it = vertList.begin(); it!=vertList.end(); it++){
        if(manhattan(it->second,startPoint)<startManDist){
            startManDist = manhattan(it->second,startPoint);
            startID=it->first;
        }

        if(manhattan(it->second,endPoint)<endManDist){
            endManDist = manhattan(it->second,endPoint);
            endID=it->first;
        }
    }
}



/*
    Read the Edmonton map data from the provided file
    and load it into the given WDigraph object.
    Store vertex coordinates in Point struct and map
    each vertex to its corresponding Point struct.

    PARAMETERS:
    filename: name of the file describing a road network
    graph: an instance of the weighted directed graph (WDigraph) class
    points: a mapping between vertex identifiers and their coordinates
*/
void readGraph(string filename, WDigraph& graph, unordered_map<int, Point>& points) {

    //File parser object declaration
    fstream file;
    file.open(filename);

    //If the file is sucessful in being opened
    if(file.is_open()){
        //Read till the end of the file
        while(!file.eof()){
            //line object creation
            string line;
            //Grab line currenty on
            getline(file,line);

            int firstCommaOcc = line.find(",");
            int secondCommaOcc = line.find(",",firstCommaOcc+1);
            int thirdCommaOcc = line.find(",",secondCommaOcc+1);

            //Adding a Vertex
            if(line[0]=='V'){
                //Grabbing the ID
                string id = line.substr( firstCommaOcc+1, secondCommaOcc-2 );

                //Grabbing the Lat and Lon
                double dlati = stod(line.substr(secondCommaOcc+1,thirdCommaOcc-secondCommaOcc-1));
                double dlongi = stod(line.substr(thirdCommaOcc+1));

                long long lati = static_cast <long long> (dlati*100000);
                long long longi = static_cast <long long> (dlongi*100000);

                //Creating a temp Point structure
                Point tempPoint;
                tempPoint.lat = lati;
                tempPoint.lon = longi;

                //Filling the structures and graph correctly
                graph.addVertex(stoi(id));
                points[stoi(id)] = tempPoint;

            }else if(line[0]=='E'){
                //Adding a line(Connection)
                int ide1 = stoi(line.substr(firstCommaOcc+1, secondCommaOcc-2  ));
                int ide2 = stoi(line.substr(secondCommaOcc+1,thirdCommaOcc-secondCommaOcc-1));

                //Calculate manhattan distance and add as the cost
                long long dist = manhattan(points[ide1],points[ide2]);

                //Adding the edge with the weight
                graph.addEdge(ide1,ide2,dist);

            }
        }
    }

    file.close();
}